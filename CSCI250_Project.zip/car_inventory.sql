-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2022 at 01:25 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csci250_databasedemo`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_inventory`
--

CREATE TABLE `car_inventory` (
  `ID` int(2) NOT NULL,
  `Car Make` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `car_inventory`
--

INSERT INTO `car_inventory` (`ID`, `Car Make`, `Image`, `Price`) VALUES
(2, 'USED 2021 Ford Bronco Sport Big Bend', 'car2.jpg', 37000.00),
(3, 'NEW 2023 Honda CR-V EX FWD', 'car3.jpg', 40000.00),
(1, 'USED 2018 Mercedes-Benz GLE-Class 350 4MATIC', 'car1.jpg', 31500.00),
(4, 'NEW 2023 Kia Sportage SX Prestige AWD', 'car4.jpg', 33550.00),
(5, 'USED Toyota RAV4 LE AWD', 'car5.jpg', 27000.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
