<html lang="en">
<head>
  <title>J&F Dealership</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>J & F CAR DEALERSHIP</h1>
</div>

<div class="container">
  <div class="row">
    <br> <br>
    <div class="col-sm-7">
      <div class="form-data">
          <div class="form-head">
              <h2>Please select one of the two options below to explore our dealership!</h2>
              <br> <br>
              <form action = "dealership_inventory.php", method = "POST">
                <input type = "submit", name = "inventoryButton", value = "Click here to view inventory!">
              </form>
              <br> OR <br> <br>
              <form action = "dealership_service.php", method = "POST">
                <input type = "submit", name = "serviceButton", value = "Click here for service!">
              </form>



          </div>
            </div>
    </div>
  </div>
</div>

</body>
</html>
