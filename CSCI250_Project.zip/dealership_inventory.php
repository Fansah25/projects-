<?php
session_start();
$connect = mysqli_connect("localhost", "root", "root", "csci250_databasedemo");
 ?>

<html lang="en">
<head>
  <title>J&F Dealership</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>J & F CAR DEALERSHIP</h1>
  <p>Welcome to our vehicle inventory page</p>
</div>
  <div class="container">
    <div class="row">
      <br> <br>
      <div class="col-sm-7">
        <div class="form-data">
            <div class="form-head">
                <h2>Browse our fabulous inventory!</h2>
                <br>
                <?php

                $query = "SELECT * from car_inventory ORDER BY id ASC";

                $result = mysqli_query($connect, $query);

                if(mysqli_num_rows($result) > 0)
                {
                  while($row = mysqli_fetch_array($result))
                  {
                 ?>
                 <div class = "col-lg-25">
                   <br>
                   <form method = "POST" action="dealership_inventory<?php echo $row["ID"]; ?>.php">
                     <div style="border: 2px solid #333; background: #f1f1f1; border-radius: 10px;" align="center"/>

                       <img src = "<?php echo $row["Image"]; ?>" width ="200" height = "200"/> <br>

                       <h4 class = "text-info"> <?php echo $row["Car Make"]; ?>  </h4>

                       <h4 class="text-info"> $<?php echo $row["Price"]; ?> </h4>

                       <input type = "hidden" name = "hidden_name" value = "<?php echo $row["name"]; ?>" />

                       <input type = "hidden" name ="hidden_price" value ="<?php echo $row["price"]; ?>" />

                       <input type = "submit" name = "learnMore" class = "btn btn-success" value = "Learn More!" />
                       <br>
                       <br>
                     </div>
                  </form>

                <?php
              }
            }
                ?>




            </div>
              </div>
      </div>
      <br>
      <form action = "dealership_home.php" action = "POST">
        <input type = "submit" name = "home" value = "Go back to homepage" />
      </form>
    </div>

  </div>

  </body>
  </html>
