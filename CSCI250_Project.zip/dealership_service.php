<?php
session_start();
$conn = mysqli_connect("localhost", "root", "root", "csci250_databasedemo");
 ?>

<html lang="en">
<head>
  <title>J&F Dealership</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>J & F CAR DEALERSHIP</h1>
<p>Welcome to our service appointment page</p>
</div>

<div class="container">
  <div class="row">
    <br> <br>
    <div class="col-sm-6">

      <div class="form-data">
          <div class="form-head">
          <h2>Request your Service Appointment</h2>
          <br>
          <h4>Personal Information </h4>
          </div>
          <div class="form-body">
            <form action="dealership_service.php", method='POST'>

                <input type="text" name = "name" placeholder="Full name" class="form-control">

              <br>

              <input type="text" name = "email" placeholder="Email Address" class="form-control">

            <br>

                <input type="text" name = "number" placeholder="Mobile Number" class="form-control">



              <br>

                <input id="dat" name = "avail" type="text" placeholder="Availability e.g 00/00/0000" class="form-control">

                <br>

               <br>
               <h4>Address Details</h4>


      <label for="inputAddress">Street Address</label>
      <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St"> <br>


      <label for="inputAddress2">Address Second Line</label>
      <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor"> <br>


        <label for="inputCity">City</label>
        <input type="text" class="form-control" id="inputCity"> <br>


        <label for="inputState">State</label>
        <select id="inputState" class="form-control"> <br>
          <option selected></option>
          <option>AL</option>
          <option>AK</option>
          <option>AZ</option>
          <option>AR</option>
          <option>CA</option>
          <option>CZ</option>
          <option>CO</option>
          <option>CT</option>
          <option>DE</option>
          <option>DC</option>
          <option>FL</option>
          <option>GA</option>
          <option>GA</option>
          <option>HI</option>
          <option>ID</option>
          <option>IL</option>
          <option>IN</option>
          <option>IA</option>
          <option>KS</option>
          <option>KY</option>
          <option>LA</option>
          <option>MD</option>
          <option>MI</option>
          <option>MN</option>
          <option>MS</option>
          <option>MO</option>
          <option>MT</option>
          <option>NE</option>
          <option>NV</option>
          <option>NH</option>
          <option>NY</option>
          <option>NJ</option>
          <option>NM</option>
          <option>NY</option>
          <option>NC</option>
          <option>ND</option>
          <option>OH</option>
          <option>OK</option>
          <option>OR</option>
          <option>PA</option>
          <option>PR</option>
          <option>RI</option>
          <option>SC</option>
          <option>SD</option>
          <option>TN</option>
          <option>TX</option>
          <option>UT</option>
          <option>VT</option>
          <option>VI</option>
          <option>VA</option>
          <option>WA</option>
          <option>WV</option>
          <option>WI</option>
          <option>WY</option>
</option>
        </select>


<br>
        <label for="inputZip">Zip</label>
        <input type="text" class="form-control" id="inputZip"> <br>

          <br>
                 <h4> Vehicle Information </h4>



                      <input type="text" placeholder="Car Brand" class="form-control">

                      <br>

                      <input type="text" placeholder="Model" class="form-control">

                      <br>

                      <input type="text" placeholder="Year" class="form-control">

                      <br>

                      <input type="text" name = "vin" placeholder="VIN Number" class="form-control">


                      <br>
                        <div class="form-group">
                        <h4> Brief Reason for Visit </h4>
                          <textarea class="form-control" name = "reason" id="reason" rows="3"></textarea>
                        </div>


    <input type = "submit", class = "btn btn-success" name = "requestButton", value = "Send Request" /> </p> <br>


    <?php
      if(isset($_POST["requestButton"])){
         if(isset($_POST["name"])){
           $name = $_POST["name"];
         }
         else
         {
           $name = "n/a";
         }

         if(isset($_POST["email"])){
           $email = $_POST["email"];
         }
         else
         {
           $email = "N/A";
         }
         if(isset($_POST["number"])){
           $number = $_POST["number"];
         }
         else
         {
           $number = "0";
         }

         if(isset($_POST["avail"])){
           $avail = $_POST["avail"];
         }
         else
         {
           $avail = "N/A";
         }
         if(isset($_POST["vin"])){
           $vin = $_POST["vin"];
         }
         else
         {
           $vin = "n/a";
         }

         if(isset($_POST["reason"])){
           $reason = $_POST["reason"];
         }
         else
         {
           $reason = "N/A";
         }


         if(!$conn){
           die("Connection failed.");
         }

         $sql = "INSERT INTO service VALUES ('$name', '$email', '$number', '$avail', '$vin', '$reason')";


         if(mysqli_query($conn, $sql)){
                  echo "<h4>Thank you for filling out the form. Our team will notify you ".
                        " within 24 business hours!</h4>";



         } else{
                  echo "ERROR: Please try again. Sorry $sql."
                  . mysqli_error($conn);
          }

          // Close connection
          mysqli_close($conn);

      }

       ?>


  </form>

  <form method = "POST" action = "dealership_home.php">
    <input type = "submit" name = "goBack" value = "Go back to homepage" />
  </form>

  </div>
</div>

</body>
</html>
