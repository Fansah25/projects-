-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2022 at 01:23 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csci250_databasedemo`
--

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `Full Name` text NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Phone Number` int(12) NOT NULL,
  `Availability` varchar(11) NOT NULL,
  `VIN` varchar(17) NOT NULL,
  `Reason` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`Full Name`, `Email`, `Phone Number`, `Availability`, `VIN`, `Reason`) VALUES
('N/A', 'N/A', 0, 'N/A', 'N/A', 'N/A'),
('N/A', 'N/A', 0, 'N/A', 'N/A', 'N/A'),
('N/A', 'N/A', 0, 'N/A', 'N/A', 'N/A'),
('julia', 'j@gmail.com', 433, '01/27/2022', '34558h', 'oil'),
('julia', 'j@gmail.com', 433, '01/27/2022', '34558h', 'oil'),
('julia', 'j@gmail.com', 433, '01/27/2022', '34558h', 'oil'),
('julia', 'j@gmail.com', 433, '01/27/2022', '34558h', 'oil'),
('julia', 'j@gmail.com', 433, '01/27/2022', '34558h', 'oil'),
('adam', 'a@gmail.com', 2016784520, '01/27/2022', 'dnjggi596', 'tire'),
('adam', 'a@gmail.com', 2016784520, '01/27/2022', 'dnjggi596', 'tire'),
('Julia Hrynkiewicz', 'juliahrynkiewiczz@gmail.com', 2013405555, '', '593bjsdu', 'tiresss');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
